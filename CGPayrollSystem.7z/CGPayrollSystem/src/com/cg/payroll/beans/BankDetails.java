package com.cg.payroll.beans;
public class BankDetails {
	private int accountNumber;
	private String bankName,ifscCode;
}
