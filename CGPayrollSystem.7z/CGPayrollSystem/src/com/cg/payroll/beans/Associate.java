package com.cg.payroll.beans;
public class Associate {
	
	private int associateID,yearlyInvestmentUnder80C;
	private String firstName,lastName,department,designation,pancard,emailId;
	private BankDetails bankDetails ;
	private Salary  salary;
	
	
}

