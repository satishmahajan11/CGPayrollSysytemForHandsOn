package com.cg.payroll.beans;
public class Salary {
	private int basicSalary, hra, conveyenceAllowance,otherAllowance,
	personalAllowance,monthlyTax, epf,
	companyPf,gratuity,grossSalary,netSalary;	
}