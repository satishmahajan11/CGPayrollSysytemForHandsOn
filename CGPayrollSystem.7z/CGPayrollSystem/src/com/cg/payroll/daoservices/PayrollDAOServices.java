package com.cg.payroll.daoservices;

public interface PayrollDAOServices {

}